$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/main/java/Features/SignUp.feature");
formatter.feature({
  "line": 1,
  "name": "Sign Up",
  "description": "",
  "id": "sign-up",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Sign Up scenario",
  "description": "",
  "id": "sign-up;sign-up-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "User is on Application Home Page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "Application Page Title is PHP Travels",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "user clicks on MY ACCOUNT",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "user clicks on Sign Up option",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "User navigate to Sign Up page",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "user enters personal data and the entered values are validated",
  "rows": [
    {
      "cells": [
        "Regina",
        "Mathew",
        "0123456789",
        "rege.mathew@gmail.com",
        "07cBe@97",
        "07cBe@97"
      ],
      "line": 10
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "click on Sign Up button",
  "keyword": "Then "
});
formatter.step({
  "line": 13,
  "name": "Close the Browser",
  "keyword": "Then "
});
formatter.match({
  "location": "SignUp.user_is_on_Application_Home_Page()"
});
formatter.result({
  "duration": 17574570100,
  "status": "passed"
});
formatter.match({
  "location": "SignUp.application_Page_Title_is_PHP_Travels()"
});
formatter.result({
  "duration": 8437900,
  "status": "passed"
});
formatter.match({
  "location": "SignUp.user_clicks_on_MY_ACCOUNT()"
});
formatter.result({
  "duration": 182581500,
  "status": "passed"
});
formatter.match({
  "location": "SignUp.user_clicks_on_Sign_Up_option()"
});
formatter.result({
  "duration": 2834673200,
  "status": "passed"
});
formatter.match({
  "location": "SignUp.user_navigate_to_Sign_Up_page()"
});
formatter.result({
  "duration": 40631200,
  "status": "passed"
});
formatter.match({
  "location": "SignUp.user_enters_personal_data(DataTable)"
});
formatter.result({
  "duration": 1537754700,
  "status": "passed"
});
formatter.match({
  "location": "SignUp.click_on_Sign_Up_button()"
});
formatter.result({
  "duration": 133515400,
  "status": "passed"
});
formatter.match({
  "location": "SignUp.close_the_Browser()"
});
formatter.result({
  "duration": 491203500,
  "status": "passed"
});
});